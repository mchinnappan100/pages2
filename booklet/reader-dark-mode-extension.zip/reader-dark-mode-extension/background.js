// Injects content.js into the active tab. content.js itself handles
// toggling (it removes the toolbar if one is already present), so
// re-running it on every click/shortcut naturally acts as an on/off switch.
function injectToolbar(tab) {
  if (!tab || !tab.id) return;
  // Skip internal chrome:// pages etc. where scripting isn't allowed.
  if (!/^https?:|^file:/.test(tab.url || "")) return;

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["content.js"],
  }).catch((err) => console.warn("Reader + Dark Mode: could not inject on this page.", err));
}

chrome.action.onClicked.addListener((tab) => injectToolbar(tab));

chrome.commands.onCommand.addListener((command, tab) => {
  if (command === "toggle-toolbar") injectToolbar(tab);
});
