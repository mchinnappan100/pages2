# Reader + Dark Mode (Chrome Extension)

Reads any webpage aloud with live word-by-word highlighting, adjustable
voice/speed, and a one-click dark mode toggle — no console, no bookmarklet.

## Install (unpacked, since it's not on the Chrome Web Store)

1. Unzip this folder somewhere permanent (don't delete it after installing —
   Chrome loads the extension from these files each time).
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select this folder.
5. You'll see the icon appear in your toolbar. Pin it (puzzle-piece icon →
   pin) for easy access.

## Use

- Click the toolbar icon on any page to open the Reader panel.
- Click it again to close it.
- Keyboard shortcut: **Alt+Shift+R** does the same toggle without touching
  the mouse. (Changeable at `chrome://extensions/shortcuts`.)

## Features

- ▶ Read the whole page aloud, with the current word highlighted in yellow
  as it's spoken (auto-scrolls to keep up).
- 📖 Read just a text selection, same word-highlighting.
- ⏸ Pause / Resume, ■ Stop.
- Voice dropdown — pick from any voice installed on your system.
- Speed slider (0.5x–2x).
- 🌙 Dark mode toggle for the current page.
- Draggable panel.

## Notes

- Doesn't work on internal `chrome://` pages (browser restriction).
- Word-level highlighting depends on the browser/voice firing per-word
  boundary events. Chrome's built-in voices support this well; some system
  voices only report sentence boundaries.
